/*
 * File:    graphics.h
 * Version: 0.0
 * Author:  Jonathan Oxer (@jonoxer)
 * License: GPLv3
 */

    byte cursorX;
    byte cursorY;
    byte cursorZ;