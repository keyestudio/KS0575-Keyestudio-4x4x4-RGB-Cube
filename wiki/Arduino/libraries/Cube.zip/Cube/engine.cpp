/*
 * File:    engine.cpp
 * Version: 0.0
 * Author:  Andy Gelme (@geekscape)
 * License: GPLv3
 *
 * Cube command engine.
 *
 * ToDo
 * ~~~~
 * - None, yet.
 */

#ifndef CUBE_cpp
#define CUBE_cpp

#include "Cube.h"
#include "engine.h"

byte executeNop(
  bytecode_t bytecode) {

  byte errorCode = 0;
  return(errorCode);
}
#endif
